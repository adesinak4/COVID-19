function test() {

    var q1 = document.getElementsByName('optradio1');
    var q1_value;
    for (var i = 0; i < q1.length; i++) {
        if (q1[i].checked) {
            q1_value = parseInt(q1[i].value);
        }
    }

    var q2 = document.getElementsByName('optradio2');
    var q2_value;
    for (var i = 0; i < q2.length; i++) {
        if (q2[i].checked) {
            q2_value = parseInt(q2[i].value);
        }
    }

    var q3 = document.getElementsByName('optradio3');
    var q3_value;
    for (var i = 0; i < q3.length; i++) {
        if (q3[i].checked) {
            q3_value = parseInt(q3[i].value);
        }
    }

    var q4 = document.getElementsByName('optradio4');
    var q4_value;
    for (var i = 0; i < q4.length; i++) {
        if (q4[i].checked) {
            q4_value = parseInt(q4[i].value)
        }
    }

    var q5 = document.getElementsByName('optradio5');
    var q5_value;
    for (var i = 0; i < q5.length; i++) {
        if (q5[i].checked) {
            q5_value = parseInt(q5[i].value);
        }
    }

    var q6 = document.getElementsByName('optradio6');
    var q6_value;
    for (var i = 0; i < q6.length; i++) {
        if (q6[i].checked) {
            q6_value = parseInt(q6[i].value);
        }
    }

    var q7 = document.getElementsByName('optradio7');
    var q7_value;
    for (var i = 0; i < q7.length; i++) {
        if (q7[i].checked) {
            q7_value = parseInt(q7[i].value);
        }
    }

    var q8 = document.getElementsByName('optradio8');
    var q8_value;
    for (var i = 0; i < q8.length; i++) {
        if (q8[i].checked) {
            q8_value = parseInt(q8[i].value);
        }
    }

    var q9 = document.getElementsByName('optradio9');
    var q9_value;
    for (var i = 0; i < q9.length; i++) {
        if (q9[i].checked) {
            q9_value = parseInt(q9[i].value);
        }
    }

    var q10 = document.getElementsByName('optradio10');
    var q10_value;
    for (var i = 0; i < q10.length; i++) {
        if (q10[i].checked) {
            q10_value = parseInt(q10[i].value);
        }
    }

    var q11 = document.getElementsByName('optradio11');
    var q11_value;
    for (var i = 0; i < q11.length; i++) {
        if (q11[i].checked) {
            q11_value = parseInt(q11[i].value);
        }
    }

    var q12 = document.getElementsByName('optradio12');
    var q12_value;
    for (var i = 0; i < q12.length; i++) {
        if (q12[i].checked) {
            q12_value = parseInt(q12[i].value);
        }
    }
    var q = q1_value + q2_value + q3_value + q4_value + q5_value + q6_value + q7_value + q8_value + q9_value + q10_value + q11_value + q12_value;
    //alert(q);
    if (q < 5) {
        location.replace("low.html");
    }
    if (q > 4 && q < 10){
        location.replace("moderate.html");
    }
    if (q > 9){
        location.replace("high.html");
    }

}